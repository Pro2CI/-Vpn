package com.violetvpn.android

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var pendingProtocol: String = "wireguard"
    private var pendingConfig: String? = null
    private var pendingSplitMode: String = "all"
    private var pendingPackages: ArrayList<String> = arrayListOf()

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        proceedWithVpnPermission()
    }

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && pendingConfig != null) {
            startTunnelService(pendingProtocol, pendingConfig!!, pendingSplitMode, pendingPackages)
            pendingConfig = null
        } else {
            pendingConfig = null
            pushStateToJs("disconnected", "Разрешение на использование Android VpnService не выдано")
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Serve bundled dist/ from app/src/main/assets/ locally
        val assetLoader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest
                ): WebResourceResponse? {
                    return assetLoader.shouldInterceptRequest(request.url)
                }
            }
            addJavascriptInterface(VioletJsBridge(), "VioletAndroidBridge")
            loadUrl("https://appassets.androidplatform.net/index.html")
        }
        setContentView(webView)

        VioletWireGuardService.stateListener = { state, error ->
            runOnUiThread { pushStateToJs(state, error) }
        }
    }

    private fun proceedWithVpnPermission() {
        val cfg = pendingConfig ?: return
        val prepIntent = VpnService.prepare(this)
        if (prepIntent != null) {
            vpnPermissionLauncher.launch(prepIntent)
        } else {
            startTunnelService(pendingProtocol, cfg, pendingSplitMode, pendingPackages)
            pendingConfig = null
        }
    }

    private fun startTunnelService(
        protocol: String,
        configText: String,
        splitMode: String,
        packages: ArrayList<String>
    ) {
        val intent = Intent(this, VioletWireGuardService::class.java).apply {
            action = VioletWireGuardService.ACTION_CONNECT
            putExtra(VioletWireGuardService.EXTRA_PROTOCOL, protocol)
            putExtra(VioletWireGuardService.EXTRA_CONFIG, configText)
            putExtra(VioletWireGuardService.EXTRA_SPLIT_MODE, splitMode)
            putStringArrayListExtra(VioletWireGuardService.EXTRA_PACKAGES, packages)
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun pushStateToJs(state: String, error: String?) {
        val stateQuoted = JSONObject.quote(state)
        val errQuoted = JSONObject.quote(error ?: "")
        val js = "window.onVioletVpnState && window.onVioletVpnState($stateQuoted, $errQuoted);"
        webView.evaluateJavascript(js, null)
    }

    inner class VioletJsBridge {
        @JavascriptInterface
        fun connect(configText: String, splitMode: String, packagesJson: String) {
            connectAny("wireguard", configText, splitMode, packagesJson)
        }

        @JavascriptInterface
        fun connectAny(protocol: String, configText: String, splitMode: String, packagesJson: String) {
            val pkgs = arrayListOf<String>()
            try {
                val arr = JSONArray(packagesJson)
                for (i in 0 until arr.length()) {
                    pkgs.add(arr.getString(i))
                }
            } catch (_: Exception) {
                // Keep empty split-tunnel list on malformed JSON
            }

            runOnUiThread {
                pendingProtocol = protocol.lowercase()
                pendingConfig = configText
                pendingSplitMode = splitMode
                pendingPackages = pkgs

                // Android 13+ requires POST_NOTIFICATIONS runtime grant so the VPN notification is visible
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val granted = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED
                    if (!granted) {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        return@runOnUiThread
                    }
                }

                proceedWithVpnPermission()
            }
        }

        @JavascriptInterface
        fun disconnect() {
            val intent = Intent(this@MainActivity, VioletWireGuardService::class.java).apply {
                action = VioletWireGuardService.ACTION_DISCONNECT
            }
            startService(intent)
        }

        @JavascriptInterface
        fun getState(): String = VioletWireGuardService.currentState
    }
}
