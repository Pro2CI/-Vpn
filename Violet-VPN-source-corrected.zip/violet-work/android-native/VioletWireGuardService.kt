package com.violetvpn.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.BufferedReader
import java.io.StringReader
import java.util.concurrent.Executors
import java.lang.reflect.Proxy
import org.json.JSONArray
import org.json.JSONObject

class VioletWireGuardService : VpnService() {

    companion object {
        const val ACTION_CONNECT = "com.violetvpn.android.CONNECT"
        const val ACTION_DISCONNECT = "com.violetvpn.android.DISCONNECT"
        const val EXTRA_PROTOCOL = "vpn_protocol"
        const val EXTRA_CONFIG = "wg_config"
        const val EXTRA_SPLIT_MODE = "split_mode"
        const val EXTRA_PACKAGES = "split_packages"
        private const val CHANNEL_ID = "violet_vpn_tunnel_v2"
        private const val NOTIFICATION_ID = 1042

        @Volatile
        var currentState: String = "disconnected"
        var stateListener: ((String, String?) -> Unit)? = null
    }

    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var backend: GoBackend
    @Volatile private var xrayTun: ParcelFileDescriptor? = null
    @Volatile private var xrayController: Any? = null

    private val tunnel = object : Tunnel {
        override fun getName(): String = "violet_wg0"
        override fun onStateChange(newState: Tunnel.State) {
            currentState = if (newState == Tunnel.State.UP) "connected" else "disconnected"
            stateListener?.invoke(currentState, null)
        }
    }

    override fun onCreate() {
        super.onCreate()
        backend = GoBackend(applicationContext)
        createNotificationChannel()
    }

    override fun onRevoke() {
        super.onRevoke()
        stopActiveTunnel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val protocol = (intent.getStringExtra(EXTRA_PROTOCOL) ?: "wireguard").lowercase()
                val rawConfig = intent.getStringExtra(EXTRA_CONFIG) ?: return START_NOT_STICKY
                val splitMode = intent.getStringExtra(EXTRA_SPLIT_MODE) ?: "all"
                val packages = intent.getStringArrayListExtra(EXTRA_PACKAGES) ?: arrayListOf()

                promoteToForeground("Подключение ($protocol)...")
                currentState = "connecting"
                stateListener?.invoke("connecting", null)

                executor.execute {
                    if (protocol == "wireguard") {
                        connectWireGuard(rawConfig, splitMode, packages)
                    } else {
                        connectWithOptionalLibbox(protocol, rawConfig)
                    }
                }
            }

            ACTION_DISCONNECT -> {
                executor.execute {
                    stopActiveTunnel()
                }
            }
        }
        return START_STICKY
    }

    private fun promoteToForeground(text: String) {
        val fgType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(text), fgType)
    }

    private fun connectWireGuard(
        rawConfig: String,
        splitMode: String,
        packages: ArrayList<String>
    ) {
        try {
            // Do not silently strip AmneziaWG obfuscation fields: that would turn a
            // different protocol into an ordinary WireGuard profile and can misreport success.
            if (rawConfig.lines().any { line ->
                    val key = line.substringBefore("=").trim().lowercase()
                    key in setOf("jc", "jmin", "jmax", "s1", "s2", "h1", "h2", "h3", "h4")
                }) {
                throw IllegalArgumentException("Это профиль AmneziaWG. В этой сборке доступен только обычный WireGuard; профиль не был изменён и не запускался.")
            }
            val cleanConfig = rawConfig
            val endpointsToTry = mutableListOf<String>()
            val backupLines = rawConfig.lines()
                .filter { it.trim().startsWith("# BackupEndpoint:", ignoreCase = true) }
                .map { it.substringAfter(":").trim() }
                .filter { it.isNotEmpty() }

            val parsedConfig = Config.parse(BufferedReader(StringReader(cleanConfig)))
            val primaryEp = parsedConfig.peers.firstOrNull()?.endpoint?.map { it.toString() }?.orElse(null)
            if (primaryEp != null) endpointsToTry.add(primaryEp)
            backupLines.forEach { if (!endpointsToTry.contains(it)) endpointsToTry.add(it) }

            var handshakeConfirmed = false
            for ((idx, candidateEp) in endpointsToTry.withIndex()) {
                val epConfigRaw = if (idx == 0) cleanConfig else cleanConfig.replace(
                    Regex("""(?im)^Endpoint\s*=.*$"""),
                    "Endpoint = $candidateEp"
                )
                val candidateParsed = Config.parse(BufferedReader(StringReader(epConfigRaw)))
                val builder = Config.Builder()
                val ifaceBuilder = com.wireguard.config.Interface.Builder()
                    .parsePrivateKey(candidateParsed.`interface`.keyPair.privateKey.toBase64())
                    .addAddresses(candidateParsed.`interface`.addresses)
                    .addDnsServers(candidateParsed.`interface`.dnsServers)

                candidateParsed.`interface`.mtu.ifPresent { ifaceBuilder.setMtu(it) }

                if (splitMode == "exclude") {
                    ifaceBuilder.excludeApplication(packageName)
                    packages.forEach { pkg -> ifaceBuilder.excludeApplication(pkg) }
                } else if (splitMode == "include" && packages.isNotEmpty()) {
                    packages.forEach { pkg -> ifaceBuilder.includeApplication(pkg) }
                } else {
                    ifaceBuilder.excludeApplication(packageName)
                }

                builder.setInterface(ifaceBuilder.build())
                builder.addPeers(candidateParsed.peers)

                // GoBackend internally calls VpnService.Builder.establish(), creating tun0 and the status-bar key icon
                backend.setState(tunnel, Tunnel.State.UP, builder.build())

                val deadline = System.currentTimeMillis() + 3500L
                while (System.currentTimeMillis() < deadline) {
                    val stats = backend.getStatistics(tunnel)
                    val hasHandshake = stats.peers().any { pk ->
                        (stats.peer(pk)?.latestHandshakeEpochMillis ?: 0L) > 0L
                    }
                    if (hasHandshake) {
                        handshakeConfirmed = true
                        break
                    }
                    Thread.sleep(350L)
                }

                if (handshakeConfirmed || idx == endpointsToTry.lastIndex) {
                    break
                }
                backend.setState(tunnel, Tunnel.State.DOWN, null)
            }

            if (!handshakeConfirmed) {
                throw IllegalStateException("Сервер WireGuard не ответил: рукопожатие не подтверждено. Проверьте конфигурацию или адрес сервера.")
            }
            currentState = "connected"
            val noteText = "VPN подключён (рукопожатие подтверждено)"
            stateListener?.invoke("connected", noteText)
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFICATION_ID, buildNotification(noteText))
        } catch (e: Exception) {
            try { backend.setState(tunnel, Tunnel.State.DOWN, null) } catch (_: Exception) { }
            currentState = "disconnected"
            stateListener?.invoke("disconnected", e.message ?: "Ошибка запуска WireGuard")
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    /**
     * Fail closed for proxy protocols until a real native engine is wired
     * to this VpnService. Unsupported protocols must never be reported as connected.
     */
    private fun connectWithOptionalLibbox(protocol: String, rawConfig: String) {
        if (protocol.equals("vless", ignoreCase = true)) {
            connectVlessWithXray(rawConfig)
            return
        }
        currentState = "disconnected"
        stateListener?.invoke("disconnected", "$protocol пока не подключён к нативному сетевому движку. VPN не запущен.")
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /**
     * Starts the official XTLS/libXray engine. Reflection is intentional: gomobile
     * generates the Java package from the Go package and the AAR is produced in CI.
     * We resolve the generated facade and DialerController interface at runtime.
     */
    private fun connectVlessWithXray(shareLink: String) {
        var tun: ParcelFileDescriptor? = null
        try {
            currentState = "connecting"
            stateListener?.invoke("connecting", "Подготовка Xray-core…")

            val facade = loadXrayFacade()
            val invokeMethod = facade.methods.firstOrNull {
                it.name == "invoke" && it.parameterTypes.contentEquals(arrayOf(String::class.java))
            } ?: throw IllegalStateException("В libXray не найден метод Invoke(String)")

            val controllerMethod = facade.methods.firstOrNull {
                it.name == "registerDialerController" && it.parameterTypes.size == 1
            } ?: throw IllegalStateException("В libXray отсутствует Android DialerController")
            val controllerType = controllerMethod.parameterTypes[0]
            val controller = Proxy.newProxyInstance(
                controllerType.classLoader,
                arrayOf(controllerType)
            ) { proxy, method, args ->
                when (method.name) {
                    "protectFd" -> {
                        val fd = (args?.firstOrNull() as? Number)?.toInt()
                            ?: throw IllegalArgumentException("Некорректный socket fd")
                        protect(fd)
                    }
                    "toString" -> "VioletVpnDialerController"
                    "hashCode" -> System.identityHashCode(proxy)
                    "equals" -> proxy === args?.firstOrNull()
                    else -> false
                }
            }
            controllerMethod.invoke(null, controller)
            xrayController = controller

            val setDns = facade.methods.firstOrNull {
                it.name == "setDNS" && it.parameterTypes.size == 2
            } ?: throw IllegalStateException("В libXray отсутствует Android DNS controller")
            setDns.invoke(null, controller, "1.1.1.1:53")

            val conversion = invokeMethod.invoke(
                null,
                JSONObject()
                    .put("apiVersion", 3)
                    .put("method", "convertShareLinksToXrayJson")
                    .put("payload", JSONObject().put("text", shareLink))
                    .toString()
            ) as? String ?: throw IllegalStateException("libXray не вернул результат разбора VLESS")
            val converted = JSONObject(conversion)
            if (!converted.optBoolean("success")) {
                throw IllegalArgumentException(converted.optString("error", "Не удалось разобрать VLESS-ссылку"))
            }
            val parsedData = converted.optJSONObject("data")
                ?: throw IllegalArgumentException("Xray не вернул outbound для этой ссылки")
            val parsedOutbounds = parsedData.optJSONArray("outbounds")
                ?: throw IllegalArgumentException("В VLESS-ссылке не найден outbound")
            if (parsedOutbounds.length() == 0) throw IllegalArgumentException("VLESS-ссылка не содержит допустимый outbound")

            val builder = Builder()
                .setSession("Violet VPN")
                .setMtu(1500)
                .addAddress("172.19.0.1", 30)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("1.1.1.1")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                builder.addAddress("fd00:19:19::1", 126)
                builder.addRoute("::", 0)
            }
            builder.addDisallowedApplication(packageName)
            tun = builder.establish() ?: throw IllegalStateException("Android не выдал VPN TUN-интерфейс")

            val outbounds = JSONArray()
            var proxyTag = parsedOutbounds.optJSONObject(0)?.optString("tag") ?: ""
            for (i in 0 until parsedOutbounds.length()) outbounds.put(parsedOutbounds.getJSONObject(i))
            if (proxyTag.isBlank()) {
                proxyTag = "proxy"
                parsedOutbounds.optJSONObject(0)?.put("tag", proxyTag)
            }
            outbounds.put(JSONObject().put("tag", "direct").put("protocol", "freedom").put("settings", JSONObject()))
            outbounds.put(JSONObject().put("tag", "block").put("protocol", "blackhole").put("settings", JSONObject()))

            val xrayConfig = JSONObject()
                .put("log", JSONObject().put("loglevel", "warning"))
                .put("env", JSONObject().put("xray.tun.fd", tun.fd.toString()))
                .put("inbounds", JSONArray().put(
                    JSONObject()
                        .put("tag", "tun-in")
                        .put("protocol", "tun")
                        .put("settings", JSONObject()
                            .put("name", "violet0")
                            .put("mtu", 1500)
                            .put("gateway", JSONArray().put("172.19.0.1/30").put("fd00:19:19::1/126"))
                            .put("dns", JSONArray().put("1.1.1.1")))
                ))
                .put("outbounds", outbounds)
                .put("routing", JSONObject().put("domainStrategy", "IPIfNonMatch").put(
                    "rules", JSONArray().put(JSONObject()
                        .put("type", "field")
                        .put("inboundTag", JSONArray().put("tun-in"))
                        .put("outboundTag", proxyTag))
                ))

            val runResponse = invokeMethod.invoke(
                null,
                JSONObject().put("apiVersion", 3).put("method", "runXray")
                    .put("payload", JSONObject().put("xrayJson", xrayConfig.toString())).toString()
            ) as? String ?: throw IllegalStateException("libXray не вернул результат запуска")
            val runJson = JSONObject(runResponse)
            if (!runJson.optBoolean("success")) {
                throw IllegalStateException(runJson.optString("error", "Xray-core не смог запуститься"))
            }

            val stateResponse = invokeMethod.invoke(
                null,
                JSONObject().put("apiVersion", 3).put("method", "getXrayState").toString()
            ) as? String ?: "{}"
            val running = JSONObject(stateResponse).optJSONObject("data")?.optBoolean("running") == true
            if (!running) throw IllegalStateException("Xray-core не подтвердил запуск туннеля")

            xrayTun = tun
            tun = null
            currentState = "connected"
            stateListener?.invoke("connected", "VLESS подключён через Xray-core")
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFICATION_ID, buildNotification("VLESS подключён через Xray-core"))
        } catch (e: Exception) {
            try { invokeXray("stopXray") } catch (_: Exception) { }
            try { resetXrayDns() } catch (_: Exception) { }
            try { tun?.close() } catch (_: Exception) { }
            xrayTun = null
            xrayController = null
            currentState = "disconnected"
            val detail = e.cause?.message ?: e.message ?: "Неизвестная ошибка запуска Xray"
            stateListener?.invoke("disconnected", "Не удалось запустить VLESS: $detail")
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun loadXrayFacade(): Class<*> {
        val names = listOf("libXray.LibXray", "libxray.LibXray")
        for (name in names) {
            try { return Class.forName(name) } catch (_: ClassNotFoundException) { }
        }
        throw IllegalStateException("Не найден класс libXray.LibXray. Проверьте, что AAR libXray собран и включён в приложение.")
    }

    private fun invokeXray(method: String) {
        invokeXrayFacadeMethod(method)
    }

    private fun invokeXrayFacadeMethod(methodName: String) {
        val facade = loadXrayFacade()
        val invoke = facade.methods.firstOrNull { it.name == "invoke" && it.parameterTypes.contentEquals(arrayOf(String::class.java)) }
            ?: throw IllegalStateException("Invoke(String) недоступен")
        val response = invoke.invoke(null, JSONObject().put("apiVersion", 3).put("method", methodName).put("payload", JSONObject()).toString()) as? String
            ?: throw IllegalStateException("libXray не вернул ответ на $methodName")
        val json = JSONObject(response)
        if (!json.optBoolean("success")) throw IllegalStateException(json.optString("error", "Ошибка libXray: $methodName"))
    }

    private fun resetXrayDns() {
        val facade = loadXrayFacade()
        val reset = facade.methods.firstOrNull { it.name == "resetDNS" && it.parameterTypes.isEmpty() }
            ?: throw IllegalStateException("ResetDNS недоступен в libXray")
        reset.invoke(null)
    }

    override fun onDestroy() {
        try { invokeXray("stopXray") } catch (_: Exception) { }
        try { resetXrayDns() } catch (_: Exception) { }
        try { xrayTun?.close() } catch (_: Exception) { }
        xrayTun = null
        xrayController = null
        super.onDestroy()
    }

    private fun stopActiveTunnel() {
        try { invokeXray("stopXray") } catch (_: Exception) { }
        try { resetXrayDns() } catch (_: Exception) { }
        try { xrayTun?.close() } catch (_: Exception) { }
        xrayTun = null
        xrayController = null
        try {
            backend.setState(tunnel, Tunnel.State.DOWN, null)
        } catch (_: Exception) {
            // Ignore when tunnel wasn't WireGuard
        }
        currentState = "disconnected"
        stateListener?.invoke("disconnected", null)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Violet VPN Туннель",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val disconnectIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, VioletWireGuardService::class.java).apply {
                action = ACTION_DISCONNECT
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Violet VPN")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(openAppIntent)
            .addAction(0, "Отключить", disconnectIntent)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setSilent(true)
            .setOngoing(true)
            .build()
    }
}
