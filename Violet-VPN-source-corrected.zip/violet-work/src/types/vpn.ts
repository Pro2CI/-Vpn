export type TabId = 'auto' | 'profiles' | 'settings';

export type ConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'disconnecting';

export type ProfileProtocol =
  | 'wireguard'
  | 'amneziawg'
  | 'openvpn'
  | 'vless'
  | 'hysteria2'
  | 'trojan'
  | 'vmess'
  | 'shadowsocks';

export type AutoSearchMode = 'all' | 'wireguard' | 'vless' | 'openvpn';

export interface AmneziaWgConfig {
  enabled: boolean;
  jc: number;
  jmin: number;
  jmax: number;
  s1: number;
  s2: number;
  h1: number;
  h2: number;
  h3: number;
  h4: number;
}

export interface OpenVpnProfileDetails {
  remoteHost: string;
  remotePort: number;
  proto: 'udp' | 'tcp';
  cipher?: string;
  hasInlineCerts: boolean;
  authUserPass: boolean;
}

export interface VlessProfileDetails {
  uuid: string;
  host: string;
  port: number;
  security: string;
  sni?: string;
  pbk?: string;
  flow?: string;
  network: string;
  uri: string;
}

export interface WireGuardProfile {
  id: string;
  name: string;
  protocol?: ProfileProtocol;
  isCustom: boolean;
  createdAt: string;
  source?: string;
  latencyMs?: number;
  rawOriginalConfig?: string;
  openvpnConfig?: OpenVpnProfileDetails;
  vlessConfig?: VlessProfileDetails;
  interfaceConfig: {
    privateKey: string;
    address: string;
    dns: string;
    mtu: number;
    amneziaWg?: AmneziaWgConfig;
  };
  peerConfig: {
    publicKey: string;
    presharedKey?: string;
    endpoint: string;
    allowedIPs: string;
    persistentKeepalive: number;
  };
  backupEndpoints?: string[];
}

export interface EndpointVerificationResult {
  reachable: boolean;
  latencyMs: number | null;
  host: string;
  port: number;
  protocol: string;
  checkedAt: string;
  note: string;
  viaBrowserFallback?: boolean;
}

export interface AndroidAppEntry {
  id: string;
  name: string;
  packageName: string;
  category: string;
  bypassVpn: boolean;
}

export type SplitTunnelMode = 'all' | 'exclude' | 'include';

export interface DnsPreset {
  id: string;
  label: string;
  address: string;
  description: string;
}

export interface VpnSettings {
  killSwitch: boolean;
  ipv6Enabled: boolean;
  dnsPresetId: string;
  mtu: number;
  keepalive: number;
  preferredWarpPort: number;
  splitTunnelMode: SplitTunnelMode;
  theme: 'dark' | 'light';
}

export interface AutoDiscoveredVpnConfig {
  id: string;
  name: string;
  source: string;
  protocol: ProfileProtocol;
  country: string;
  endpoint: string;
  latencyMs: number | null;
  reachable: boolean;
  rfCompatible: boolean;
  configText: string;
  wireguardProfile?: WireGuardProfile;
  backupEndpoints?: string[];
  note?: string;
}

export interface AutoSearchResponse {
  searchedAt: string;
  scannedCandidates: number;
  workingCount: number;
  sourcesChecked: Array<{
    name: string;
    status: 'ok' | 'partial' | 'unavailable';
    found: number;
    detail: string;
  }>;
  configs: AutoDiscoveredVpnConfig[];
}

export interface ActiveVpnSession {
  sessionId: string;
  name: string;
  protocol: ProfileProtocol;
  endpoint: string;
  resolvedIp?: string;
  connectedAtMs: number;
  latencyMs: number | null;
  checksCount: number;
  mode: 'native-android' | 'app-relay';
  detail: string;
}

export interface SavedSubscriptionFeed {
  id: string;
  name: string;
  url: string;
  enabled: boolean;
}

